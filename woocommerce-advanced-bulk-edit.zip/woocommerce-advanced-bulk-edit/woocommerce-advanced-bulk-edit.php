<?php
/*
Plugin Name: ویرایش گروهی محصولات ووکامرس
Plugin URI: https://wpmelon.com
Description: محصولاتتون رو بصورت تکی یا گروهی ویرایش کنید.
Author: George Iron & Yas G.
Author URI: https://wpmelon.com
Version: 5.4.4.7.1
Text Domain: woocommerce-advbulkedit
Requires Plugins: woocommerce
WC requires at least: 5.0
WC tested up to: 9.3.3
*/

defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );

add_action( 'before_woocommerce_init', function() {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

define('WCABE_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('WCABE_VERSION', '5.4.4.7.1');
define('WCABE_SITE_URL', 'https://wpmelon.com');
define('WCABE_SUPPORT_URL', 'https://wpmelon.com/r/support');
define('WCABE_SUPPORT_JS_NOTICE_MORE_INFO_URL', 'https://wpmelon.com/r/support-sj-notice-more-info');
define('WCABE_UPDATE_INFO_URL', 'https://wpmelon.com/r/wcabe-update-info');
define('WCABE_UPDATE_URL', 'https://wpmelon-updates.com/be/api/v1/getupdate');
define( 'WCABE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define('WCABE_E_R', false);

require_once WCABE_PLUGIN_PATH . 'includes/notices/rate.php';
require_once WCABE_PLUGIN_PATH . 'includes/notices/getting-started.php';
require_once WCABE_PLUGIN_PATH . 'includes/helpers/general.php';
require_once WCABE_PLUGIN_PATH . 'includes/helpers/products.php';
require_once WCABE_PLUGIN_PATH . 'includes/helpers/integrations.php';
require_once WCABE_PLUGIN_PATH . 'includes/classes/product-attribute-updater.php';
require_once WCABE_PLUGIN_PATH . './loader.php';